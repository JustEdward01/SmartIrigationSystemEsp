#include <Arduino.h>
#include "config.h"
#include "wifi_manager.h"
#include "buffer_manager.h"
#include "sensors.h"
#include "pump_controller.h"
#include "security.h"
#include "debug_server.h"
#include <HTTPClient.h>
#include <esp_task_wdt.h>
WiFiManagerESP wifiManager;
BufferManager bufferManager;
Sensors sensors;
PumpController pumpController;
WebServer server(80);
DebugServer debugServer(server);

unsigned long lastSend = 0;
const unsigned long SEND_INTERVAL = 60000; // 60s (modifică dacă vrei alt interval)

unsigned long lastRetry = 0;
unsigned long retryWait = 10000; // 10 sec inițial

bool sendToServer(const String& payload) {
    if (wifiManager.status() != WIFI_OK) return false;
    HTTPClient http;
    http.begin(BACKEND_URL);
    http.addHeader("Content-Type", "application/json");
    int code = http.POST(payload);
    String resp = http.getString();
    http.end();
    return code == 200 && Security::validateServerResponse(resp);
}

void runMainLogic() {
    SensorData data = sensors.readAll();
    String payload = sensors.toJSON(data);
    if (wifiManager.status() == WIFI_OK) {
        if (sendToServer(payload)) {
            bufferManager.flushToServer(sendToServer);
            retryWait = 10000;
        } else {
            bufferManager.save(payload);
            lastRetry = millis();
            retryWait *= 2;
            if (retryWait > 600000) retryWait = 600000;
        }
    } else {
        bufferManager.save(payload);
    }
}

void tryRetryFlush() {
    if (wifiManager.status() == WIFI_OK && millis() - lastRetry > retryWait) {
        bufferManager.flushToServer(sendToServer);
        lastRetry = millis();
    }
}

void setup() {
    Serial.begin(115200);
    wifiManager.init();
    bufferManager.init();
    sensors.init();
    pumpController.init();
    debugServer.setupEndpoints();
    esp_task_wdt_init(10, true);
    esp_task_wdt_add(NULL);
}

void loop() {
    esp_task_wdt_reset();
    if (wifiManager.isAPMode()) {
        wifiManager.handleServer();
        delay(10);
        return;
    }
    unsigned long now = millis();
    if (now - lastSend > SEND_INTERVAL) {
        lastSend = now;
        runMainLogic();
    }
    tryRetryFlush();
}
