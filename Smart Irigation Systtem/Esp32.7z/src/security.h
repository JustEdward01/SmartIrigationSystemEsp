#pragma once
#include <Arduino.h>
namespace Security {
    bool validateServerResponse(const String& payload);
}
